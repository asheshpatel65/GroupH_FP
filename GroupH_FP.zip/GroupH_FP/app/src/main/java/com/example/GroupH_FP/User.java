package com.example.GroupH_FP;

public class User {
    String name, email, mobile;
    int imageId;

    public User(String name, String email, String mobile, int imageId) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.imageId = imageId;
    }
}
